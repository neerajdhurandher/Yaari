package com.example.apptrail4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    public static final String loginkey = "com.example.apptrail4.loginkey";
    EditText emailId, password;
    Button btnsignup;
    Button btnLogin;
   FirebaseAuth mFirebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mFirebaseAuth = FirebaseAuth.getInstance();

        emailId = findViewById(R.id.etemailid);
        password = findViewById(R.id.etpassword);
        btnsignup = findViewById(R.id.btnSignUp);
        btnLogin = findViewById(R.id.textView);

        btnsignup.setOnClickListener(new View.OnClickListener () {

//            @android.support.annotation.RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
            @Override
            public void onClick(View v) {

                String emailstr = emailId.getText().toString();
                String passwordstr = password.getText().toString();
                if (emailstr.isEmpty()) {
                    emailId.setError("Please Enter email Id");
                    emailId.requestFocus();
                } else if (passwordstr.isEmpty()) {
                    emailId.setError("Please Enter Password");
                    password.requestFocus();
                } else if (emailstr.isEmpty() && passwordstr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fields Are Empty", Toast.LENGTH_LONG).show();
                } else if (!(emailstr.isEmpty() && passwordstr.isEmpty())) {
                    mFirebaseAuth.createUserWithEmailAndPassword(emailstr, passwordstr).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                Toast.makeText(MainActivity.this, "SignUp Unsuccessful, Please Try Again", Toast.LENGTH_SHORT).show();
                            } else {
                                startActivity(new Intent(MainActivity.this, HomeActivity.class));
                            }
                        }

                    });
                } else {
                    Toast.makeText(MainActivity.this, "Error Occurred!", Toast.LENGTH_SHORT).show();

                }}

            });

         btnLogin.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(MainActivity.this,LoginActivity.class);
            startActivity(i);
            String massage = "Welcome"+emailId.getText().toString();
            i.putExtra(loginkey,massage);

        }
    });

}
}
